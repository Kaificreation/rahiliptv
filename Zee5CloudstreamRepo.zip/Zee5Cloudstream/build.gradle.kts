version = 1
cloudstream {
    description = "Zee5 Extension with Live TV and VOD (WIP)"
    authors = listOf("OpenAI")
}